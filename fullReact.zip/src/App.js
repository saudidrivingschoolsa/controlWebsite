import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'; // استيراد الحزم الضرورية
import AllUsers from './components/Dashbord';  // الصفحة الرئيسية
import Analytics from './components/Analytics';  // صفحة التحليلات
import AdminManagement from './components/AdminManagement';  // صفحة إدارة الأدمن
import Login from './components/Login';






function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} /> {/* الصفحة الرئيسية */}
        <Route path="/analytics" element={<Analytics />} /> {/* صفحة التحليلات */}
        <Route path="/admin-management" element={<AdminManagement />} /> {/* صفحة إدارة الأدمن */}
         <Route path="/login" element={<Login />} />
         <Route path="/dashboard" element={<AllUsers />} />
      
      </Routes>
    </Router>
  );
}

export default App;

