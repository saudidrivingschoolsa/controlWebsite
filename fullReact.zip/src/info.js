

import React, { useEffect, useState } from 'react';

function HelloWorld() {
  const [data, setData] = useState([]);  // To store the fetched data
  const [loading, setLoading] = useState(true);  // To track loading state
  const [error, setError] = useState(null);  // To store any errors that occur
  const [selectedColor, setSelectedColor] = useState(''); // To store the selected color

  useEffect(() => {
    // Using fetch to get data from API
    fetch('http://localhost:5000/api/')
      .then((response) => {
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        return response.json();
      })
      .then((data) => {
        setData(data);  
        setLoading(false);  
      })
      .catch((error) => {
        setError(error.message);  // Store the error if it happens
        setLoading(false);  // Update loading state even if there's an error
      });
  }, []);  // [] means this effect will run only once when the component loads

  // Handle color change for each row
  const handleColorChange = (event, rowIndex) => {
    const newData = [...data];
    newData[rowIndex].color = event.target.value; // Save the color for the selected row
    setData(newData); // Update the data
  };

  // Handle checkbox change for the 'Block' field
  const handleCheckboxChange = (event, rowIndex) => {
    const newData = [...data];
    newData[rowIndex].block = event.target.checked ? 1 : 0; // Change block value
    setData(newData); // Update the data
  };


   const handleBlockToggle = (index) => {
    const newData = [...data];
    newData[index].block = !newData[index].block; // Toggle block value
    setData(newData); // Update the data
  };

  if (loading) {
    return <h1>Loading data...</h1>;
  }

  if (error) {
    return <h1>Error: {error}</h1>;
  }

  return (
    <div>
      
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <a className="navbar-brand" href="#">Dashbord</a>
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item active">
              <a className="nav-link text-danger" href="#">Delete All User</a>
            </li>
          </ul>
          <form className="form-inline my-2 my-lg-0">
            <input className="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" />
            <button className="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
          </form>
             <button className="btn btn-warning my-2 my-sm-0 ml-2" type="submit">Hide offline</button>
             <button className="btn btn-danger my-2 my-sm-0 ml-2" type="submit">Logout</button>
        </div>
      </nav>

      <div class="container mt-4 mb-4">
        <div class="d-flex justify-content-around">
            <button type="button" class="btn btn-primary col-5">Dashbord</button>
            <button type="button" class="btn btn-secondary col-5">Analytics</button>
        </div>
      </div>
      

     


      {/* Bootstrap JS and dependencies */}
      <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
    </div>
  );
}

export default HelloWorld;
