import React, { useState, useEffect } from 'react';
import { Modal, Button, Table, Form, Tab, Tabs } from 'react-bootstrap';

function AdminManagement() {
  const [admins, setAdmins] = useState([]);
  const [errorMessages, setErrorMessages] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [showAddErrorModal, setShowAddErrorModal] = useState(false);
  const [selectedAdmin, setSelectedAdmin] = useState(null);
  const [selectedError, setSelectedError] = useState(null);
  const [newAdmin, setNewAdmin] = useState({ name: '', password: '', color: '#000000' });
  const [newPassword, setNewPassword] = useState('');
  const [newErrorMessage, setNewErrorMessage] = useState('');
  const [activeTab, setActiveTab] = useState('admins');

  // جلب البيانات من الـ API عند تحميل الصفحة
  useEffect(() => {
    fetchAdmins();
    fetchErrorMessages();
  }, []);

  const fetchAdmins = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/Full_info_ToAdmin');
      const data = await response.json();
      setAdmins(data);
    } catch (error) {
      console.error('Error fetching admin data:', error);
    }
  };

  const fetchErrorMessages = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/Get_Error_Messages');
      const data = await response.json();
      setErrorMessages(data);
    } catch (error) {
      console.error('Error fetching error messages:', error);
    }
  };

  const handleAddAdmin = async (e) => {
    e.preventDefault();

    if (!newAdmin.name || !newAdmin.password || !newAdmin.color) {
      alert("Please fill in all fields.");
      return;
    }

    const newAdminObj = {
      F_name: newAdmin.name,
      PASSWORD: newAdmin.password,
      Admin_Color: newAdmin.color,
    };

    try {
      const response = await fetch('http://localhost:5000/api/Add_Admin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newAdminObj),
      });

      if (response.ok) {
        const data = await response.json();
        setAdmins([...admins, { ...newAdminObj, id: data.user_id }]);
        setNewAdmin({ name: '', password: '', color: '#000000' });
        setShowAddModal(false);
      } else {
        console.error('Error:', await response.json());
      }
    } catch (error) {
      console.error('Error adding admin:', error);
    }
  };

  const handleUpdatePassword = async (e) => {
    e.preventDefault();
    const passwordObj = { id: selectedAdmin, old_password: '', new_password: newPassword };

    try {
      const response = await fetch('http://localhost:5000/api/Update_Password_Admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(passwordObj),
      });

      if (response.ok) {
        setNewPassword('');
        setShowUpdateModal(false);
        alert('Password updated successfully!');
      } else {
        console.error('Error:', await response.json());
      }
    } catch (error) {
      console.error('Error updating password:', error);
    }
  };

  const handleDeleteAdmin = async () => {
    if (!selectedAdmin) {
      alert('No admin selected');
      return;
    }

    try {
      const response = await fetch(`http://localhost:5000/api/Delete_Admin/${selectedAdmin}`, {
        method: 'GET',
      });

      if (response.ok) {
        setAdmins(admins.filter(admin => admin.id !== selectedAdmin));
        setShowDeleteModal(false);
      } else {
        console.error('Error:', await response.json());
      }
    } catch (error) {
      console.error('Error deleting admin:', error);
    }
  };

  const handleAddErrorMessage = async (e) => {
    e.preventDefault();
    
    if (!newErrorMessage) {
      alert("Please enter an error message");
      return;
    }

    const errorObj = {
      message: newErrorMessage,
      time: new Date().toISOString()
    };

    try {
      const response = await fetch('http://localhost:5000/api/Add_Error_Messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(errorObj),
      });

      if (response.ok) {
        const data = await response.json();
        setErrorMessages([...errorMessages, { ...errorObj, id: data.id }]);
        setNewErrorMessage('');
        setShowAddErrorModal(false);
      } else {
        console.error('Error:', await response.json());
      }
    } catch (error) {
      console.error('Error adding error message:', error);
    }
  };

  const handleDeleteErrorMessage = async () => {
    if (!selectedError) {
      alert('No error message selected');
      return;
    }

    try {
      const response = await fetch(`http://localhost:5000/api/Delete_Error_Message?id=${selectedError}`, {
        method: 'GET',
      });

      if (response.ok) {
        setErrorMessages(errorMessages.filter(error => error.id !== selectedError));
        setShowErrorModal(false);
      } else {
        console.error('Error:', await response.json());
      }
    } catch (error) {
      console.error('Error deleting error message:', error);
    }
  };

  const openDeleteModal = (adminId) => {
    setSelectedAdmin(adminId);
    setShowDeleteModal(true);
  };

  const openUpdateModal = (adminId) => {
    setSelectedAdmin(adminId);
    setShowUpdateModal(true);
  };

  const openErrorModal = (errorId) => {
    setSelectedError(errorId);
    setShowErrorModal(true);
  };

  return (
    <div className="container mt-5">
      <h1>Admin Management</h1>

      <Tabs activeKey={activeTab} onSelect={(k) => setActiveTab(k)} className="mb-3">
        <Tab eventKey="admins" title="Admins Management">
          <div className="mt-3">
            <Button variant="primary" onClick={() => setShowAddModal(true)} className="mb-3">
              Add Admin
            </Button>

            <Table bordered>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Full Name</th>
                  <th>Role</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {admins.map(admin => (
                  <tr key={admin.id} style={{ backgroundColor: admin.User_Selected_color }}>
                    <td>{admin.id}</td>
                    <td>{admin.F_name} {admin.S_name}</td>
                    <td>{admin.Role}</td>
                    <td>
                      <Button variant="warning" size="sm" onClick={() => openUpdateModal(admin.id)} className="me-2">
                        Update Password
                      </Button>
                      <Button variant="danger" size="sm" onClick={() => openDeleteModal(admin.id)}>
                        Delete
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </Tab>

        <Tab eventKey="errors" title="Error Messages">
          <div className="mt-3">
            <Button variant="primary" onClick={() => setShowAddErrorModal(true)} className="mb-3">
              Add Error Message
            </Button>

            <Table bordered>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Message</th>
                  <th>Time</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {errorMessages.map(error => (
                  <tr key={error.id}>
                    <td>{error.id}</td>
                    <td>{error.message}</td>
                    <td>{new Date(error.time).toLocaleString()}</td>
                    <td>
                      <Button variant="danger" size="sm" onClick={() => openErrorModal(error.id)}>
                        Delete
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </Tab>
      </Tabs>

      {/* Add Admin Modal */}
      <Modal show={showAddModal} onHide={() => setShowAddModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Add Admin</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleAddAdmin}>
            <Form.Group className="mb-3">
              <Form.Label>Name</Form.Label>
              <Form.Control type="text" value={newAdmin.name} onChange={(e) => setNewAdmin({ ...newAdmin, name: e.target.value })} required />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" value={newAdmin.password} onChange={(e) => setNewAdmin({ ...newAdmin, password: e.target.value })} required />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Select Color</Form.Label>
              <Form.Control type="color" value={newAdmin.color} onChange={(e) => setNewAdmin({ ...newAdmin, color: e.target.value })} required />
            </Form.Group>
            <Button variant="success" type="submit">Add Admin</Button>
          </Form>
        </Modal.Body>
      </Modal>

      {/* Update Password Modal */}
      <Modal show={showUpdateModal} onHide={() => setShowUpdateModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Update Password</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleUpdatePassword}>
            <Form.Group className="mb-3">
              <Form.Label>New Password</Form.Label>
              <Form.Control type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
            </Form.Group>
            <Button variant="warning" type="submit">Update Password</Button>
          </Form>
        </Modal.Body>
      </Modal>

      {/* Delete Admin Confirmation Modal */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Delete</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Are you sure you want to delete this admin?</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>Cancel</Button>
          <Button variant="danger" onClick={handleDeleteAdmin}>Delete</Button>
        </Modal.Footer>
      </Modal>

      {/* Add Error Message Modal */}
      <Modal show={showAddErrorModal} onHide={() => setShowAddErrorModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Add Error Message</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleAddErrorMessage}>
            <Form.Group className="mb-3">
              <Form.Label>Error Message</Form.Label>
              <Form.Control 
                as="textarea" 
                rows={3} 
                value={newErrorMessage} 
                onChange={(e) => setNewErrorMessage(e.target.value)} 
                required 
              />
            </Form.Group>
            <Button variant="success" type="submit">Add Message</Button>
          </Form>
        </Modal.Body>
      </Modal>

      {/* Delete Error Message Confirmation Modal */}
      <Modal show={showErrorModal} onHide={() => setShowErrorModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Delete</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Are you sure you want to delete this error message?</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowErrorModal(false)}>Cancel</Button>
          <Button variant="danger" onClick={handleDeleteErrorMessage}>Delete</Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default AdminManagement;