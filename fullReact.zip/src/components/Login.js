import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Login() {
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    F_name: '',
    password: ''
  });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { F_name, password } = formData;

    // تحقق من أن البيانات ليست فارغة
    if (!F_name || !password) {
      setError('Please provide both username and password');
      return;
    }

    try {
      const response = await fetch('http://localhost:5000/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ F_name, password })
      });

      const data = await response.json();
      if (data.success) {
       
        localStorage.setItem('token', data.token);
        localStorage.setItem('userId', data.userId);  // حفظ الـ id
        navigate('/dashboard'); 
      } else {
        setError(data.message); // عرض رسالة الخطأ إذا فشل تسجيل الدخول
      }
    } catch (error) {
      setError('An error occurred. Please try again.');
    }
  };

  return (
    <div className="container mt-5">
      <h2>Login</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="F_name" className="form-label">Full Name</label>
          <input
            type="text"
            className="form-control"
            id="F_name"
            name="F_name"
            value={formData.F_name}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="password" className="form-label">Password</label>
          <input
            type="password"
            className="form-control"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">Login</button>
      </form>
      <p className="mt-3">Don't have an account? <a href="/signup">Sign up here</a></p>
    </div>
  );
}

export default Login;
