import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Analytics() {
  const [analyticsData, setAnalyticsData] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetch('http://localhost:5000/api/Analytics')
      .then(response => response.json())
      .then(data => setAnalyticsData(data))
      .catch(error => console.error('Error fetching analytics data:', error));
  }, []);

  // دالة للرجوع إلى الصفحة السابقة
  const handleGoBack = () => {
    navigate('/');
  };

  return (
    <div className="container mt-4">
      <button className="btn btn-primary mb-4" onClick={handleGoBack}>
        Go Back
      </button>

      {analyticsData ? (
        <div>
          <div className="row">
            {/* إجمالي الزوار */}
            <div className="col-md-4 mb-3">
              <div className="card p-3">
                <h3>Total Visitors</h3>
                <p>{analyticsData.total_visitors}</p>
              </div>
            </div>

            {/* الزوار حسب الدولة */}
            <div className="col-md-4 mb-3">
              <div className="card p-3">
                <h3>Visitors by Country</h3>
                <table className="table table-striped">
                  <thead>
                    <tr>
                      <th>Country</th>
                      <th>Unique Visitors</th>
                      <th>IP Addresses</th>
                    </tr>
                  </thead>
                  <tbody>
                    {analyticsData.visitors_by_country.map((item, index) => (
                      <tr key={index}>
                        <td>{item.country}</td>
                        <td>{item.unique_visitors}</td>
                        <td>{item.ip_addresses}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* الزوار المكررين */}
            <div className="col-md-4 mb-3">
              <div className="card p-3">
                <h3>Duplicate Visitors</h3>
                {analyticsData.duplicate_visitors.length === 0 ? (
                  <p>No duplicate visitors</p>
                ) : (
                  <ul>
                    {analyticsData.duplicate_visitors.map((visitor, index) => (
                      <li key={index}>
                        IP: {visitor.ip}, Visit Count: {visitor.visit_count}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center">
          <div className="spinner-border text-primary" role="status">
            <span className="sr-only">Loading...</span>
          </div>
          <p>Loading Analytics...</p>
        </div>
      )}
    </div>
  );
}

export default Analytics;
