import React, { useState, useEffect, useRef } from 'react';
import { io } from 'socket.io-client';

const socket = io('http://localhost:5000'); // الاتصال مع السيرفر

function Signup() {
  const [userData, setUserData] = useState({
    ip: '',
    sessionID: '',
    country: '',
    userId: null,
    isOnline: false, // حالة الاتصال
   
  });
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRegistering, setIsRegistering] = useState(false);
  const [formData, setFormData] = useState({
    input1_1: '',
    input1_2: '',
    input1_3: '',
    input1_4: '',
    input1_5: ''
  });
  const [isFormSubmitted, setIsFormSubmitted] = useState(false);
  const isInitialized = useRef(false);








    // دالة للتحقق من صلاحية المستخدم في Page1_Nav
  const checkPage1Access = async (userId) => {
    try {
      const response = await fetch('http://localhost:5000/api/Page1_Nav', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
       body: JSON.stringify({ user_id: userId })
      });
      
      const data = await response.json();
      
      if (data.success == true) {
        // تحويل مباشر إلى /page2 ومنع العودة
        window.location.replace('/page2');
        return false;
      }
      
      return data.success;
    } catch (error) {
      console.error('Error checking page1 access:', error);
      return false;
    }
  };




  // توليد session ID عشوائي
  const generateSessionID = () => {
    const length = Math.floor(Math.random() * 6) + 4;
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    return Array.from({ length }, () => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
  };

  // جلب بيانات الموقع
  const fetchUserGeoData = async () => {
    try {
      const ipResponse = await fetch('https://api.ipify.org?format=json');
      const { ip } = await ipResponse.json();
      
      const countryResponse = await fetch(`https://ipinfo.io/${ip}/json`);
      const { country } = await countryResponse.json();
      
      return { ip, country };
    } catch (error) {
      console.error('Error fetching geo data:', error);
      throw error;
    }
  };

  // إرسال البيانات إلى الخادم
  const registerUser = async (ip, sessionID, country) => {
    try {
      const response = await fetch('http://localhost:5000/api/Signup2', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          F_name: ' ',
          PASSWORD: ' ',
          role: 'user',
          stats: 0, // بداية بحالة أوفلاين
          block: 0,
          ip,
          user_session_id: sessionID,
          country
        })
      });

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error registering user:', error);
      throw error;
    }
  };

  // التحقق من صحة المستخدم
  const validateUser = async (userId) => {
    try {
      const response = await fetch(`http://localhost:5000/api/validateUserId?userId=${userId}`);
      const data = await response.json();
      return data.success;
    } catch (error) {
      console.error('Error validating user:', error);
      return false;
    }
  };







  
  // تحديث حالة الصفحة النشطة
  const updateActivePage = async (userId, activePage) => {
    try {
      const response = await fetch('http://localhost:5000/api/updateActivePage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          activePage: activePage
        })
      });

      const data = await response.json();
      console.log('Active page updated successfully:', data);
    } catch (error) {
      console.error('Error updating active page:', error);
    }
  };

useEffect(() => {
  const sendActivePage = async () => {
    if (userData.userId) {
      try {
        await updateActivePage(userData.userId, 'Page1');
        console.log('Active page sent to database');
      } catch (error) {
        console.error('Error sending active page:', error);
      }
    }
  };

  sendActivePage();

  

}, [userData.userId]);




  


  // تحديث حالة الاتصال في الباكند
  const updateOnlineStatus = (userId, isOnline) => {
    if (userId) {
      socket.emit('updateActivity', userId);
       socket.emit('updateUserData', userId, isOnline ? 1 : 0);
        socket.emit('setOnline', userId);  // إرسال حالة الاتصال
    socket.emit('updateUserData', userId, isOnline ? 1 : 0);  // إرسال البيانات المعدلة
      setUserData(prev => ({ ...prev, isOnline }));
    }
  };



  useEffect(() => {
  if (userData.userId) {
    updateOnlineStatus(userData.userId, true);  // تحديث الحالة إلى أونلاين عند تحميل البيانات
  }

  // تأكد من إيقاف الاستماع على السوكيت عند مغادرة الصفحة
  return () => {
    if (userData.userId) {
      updateOnlineStatus(userData.userId, false);  // تحديث الحالة إلى أوفلاين عند مغادرة الصفحة
    }
  };
}, [userData.userId]);  // يعتمد على userId لتحديث الحالة


  // تهيئة المستخدم
  const initializeUser = async () => {
    if (isInitialized.current) return;
    isInitialized.current = true;
    
    setIsLoading(true);
    try {
      const storedData = {
        ip: localStorage.getItem('userIP'),
        sessionID: localStorage.getItem('userSessionID'),
        country: localStorage.getItem('userCountry'),
        userId: localStorage.getItem('userId')
      };

      if (storedData.userId) {
        const isValid = await validateUser(storedData.userId);
        if (isValid) {
          setUserData(storedData);
          updateOnlineStatus(storedData.userId, true); // تحديث الحالة إلى أونلاين
          setIsLoading(false);
          return;
        } else {
          localStorage.removeItem('userId');
          localStorage.removeItem('userIP');
          localStorage.removeItem('userSessionID');
          localStorage.removeItem('userCountry');
        }
      }

      if (isRegistering) {
        return;
      }

      setIsRegistering(true);

      const { ip, country } = await fetchUserGeoData();
      const sessionID = generateSessionID();
      
      const registration = await registerUser(ip, sessionID, country);
      
      if (registration.success) {
        const newUserData = {
          ip,
          sessionID,
          country,
          userId: registration.userId,
          isOnline: true
        };
        
        setUserData(newUserData);
        updateOnlineStatus(registration.userId, true); // تحديث الحالة إلى أونلاين
        localStorage.setItem('userIP', ip);
        localStorage.setItem('userSessionID', sessionID);
        localStorage.setItem('userCountry', country);
        localStorage.setItem('userId', registration.userId);
      }
    } catch (error) {
      console.error('Initialization error:', error);
    } finally {
      setIsLoading(false);
      setIsRegistering(false);
    }
  };

  // التحقق من حالة الصفحة وتحديثها كل 5 ثواني
  useEffect(() => {
    // تحديث حالة الصفحة النشطة كل 5 ثواني
    const interval = setInterval(() => {
      if (userData.userId) {
        socket.emit('setOnline', userData.userId); // تحديث حالة الاتصال على السيرفر
       // setUserData(prev => ({ ...prev, activePage: 'Page1' })); // تعيين الصفحة النشطة إلى Page1
      }
    }, 5000);

    // تنظيف الـ interval عند مغادرة الصفحة
    return () => clearInterval(interval);
  }, [userData.userId]);

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    const allFieldsFilled = Object.values(formData).every(value => value.trim() !== '');
    if (!allFieldsFilled) {
      alert('الرجاء ملء جميع الحقول المطلوبة');
      return;
    }

    const { input1_1, input1_2, input1_3, input1_4, input1_5 } = formData;




    const dataToSend = {
      input1_1,
      input1_2,
      input1_3,
      input1_4,
      input1_5,
      user_id: userData.userId,
    };

    setMessages([ ...messages, `Submitted Data: ${JSON.stringify(dataToSend)}` ]);

    try {
      const response = await fetch('http://localhost:5000/api/Page1', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dataToSend)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'فشل إرسال البيانات');
      }

      const data = await response.json();
      console.log('تم إرسال البيانات بنجاح:', data);
      setIsFormSubmitted(true);
       window.location.replace('/page2');


    } catch (error) {
      console.error('خطأ في إرسال البيانات:', error);
      setIsFormSubmitted(false);
    }
  };

  useEffect(() => {
    initializeUser();

    // إعداد معالج حدث قطع الاتصال
    socket.on('disconnect', () => {
      if (userData.userId) {
        setUserData(prev => ({ ...prev, isOnline: false }));
      }
    });

    // تنظيف عند إلغاء التثبيت
    return () => {
      if (userData.userId) {
        // عند إغلاق الصفحة، تحديث الحالة إلى أوفلاين
        socket.emit('disconnect', userData.userId);
      }
      socket.off('disconnect');
    };
  }, [userData.userId]);

  if (isLoading) {
    return (
      <div style={styles.container}>
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <h2>User Registration</h2>

      {messages.length > 0 && (
        <div>
          {messages.map((msg, index) => (
            <div key={index} style={styles.message}>
              {msg}
            </div>
          ))}
        </div>
      )}

      {!isFormSubmitted && (
        <form onSubmit={handleFormSubmit}>
          <div style={styles.dataRow}>
            <label htmlFor="input1_1">Field 1-1:</label>
            <input
              type="text"
              id="input1_1"
              value={formData['input1_1']}
              onChange={(e) => setFormData({ ...formData, 'input1_1': e.target.value })}
            />
          </div>

          <div style={styles.dataRow}>
            <label htmlFor="input1_2">Field 1-2:</label>
            <input
              type="text"
              id="input1_2"
              value={formData['input1_2']}
              onChange={(e) => setFormData({ ...formData, 'input1_2': e.target.value })}
            />
          </div>

          <div style={styles.dataRow}>
            <label htmlFor="input1_3">Field 1-3:</label>
            <input
              type="text"
              id="input1_3"
              value={formData['input1_3']}
              onChange={(e) => setFormData({ ...formData, 'input1_3': e.target.value })}
            />
          </div>

          <div style={styles.dataRow}>
            <label htmlFor="input1_4">Field 1-4:</label>
            <input
              type="text"
              id="input1_4"
              value={formData['input1_4']}
              onChange={(e) => setFormData({ ...formData, 'input1_4': e.target.value })}
            />
          </div>

          <div style={styles.dataRow}>
            <label htmlFor="input1_5">Field 1-5:</label>
            <input
              type="text"
              id="input1_5"
              value={formData['input1_5']}
              onChange={(e) => setFormData({ ...formData, 'input1_5': e.target.value })}
            />
          </div>

          <button type="submit" style={styles.button}>Submit</button>
        </form>
      )}

      {isFormSubmitted && <p>Form submitted successfully!</p>}
    </div>
  );
}

const styles = {
  container: {
    maxWidth: '400px',
    margin: '30px auto',
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '8px'
  },
  message: {
    marginBottom: '15px',
    padding: '10px',
    borderRadius: '4px',
  },
  dataRow: {
    marginBottom: '10px',
    padding: '8px',
    backgroundColor: '#f5f5f5',
    borderRadius: '4px'
  },
  button: {
    backgroundColor: '#4CAF50',
    color: 'white',
    padding: '10px 20px',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer'
  }
};

export default Signup;
