import React, { useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { useNavigate } from 'react-router-dom';

// الاتصال مع السيرفر
const socket = io('http://localhost:5000');

function Page4() {
  const [userId, setUserId] = useState(null);
  const [userData, setUserData] = useState(null);
  const [formData, setFormData] = useState({
    input1_1: '',
    input1_2: '',
    input1_3: '',
    input1_4: '',
    input1_5: ''
  });
  const [messages, setMessages] = useState([]);
  const [isFormSubmitted, setIsFormSubmitted] = useState(false);
  const navigate = useNavigate();

  // تحديث حالة الصفحة النشطة
  const updateActivePage = async (userId, activePage) => {
    try {
      const response = await fetch('http://localhost:5000/api/updateActivePage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          activePage: activePage
        })
      });

      const data = await response.json();
      console.log('Active page updated successfully:', data);
    } catch (error) {
      console.error('Error updating active page:', error);
    }
  };

  // تحديث حالة الاتصال في الباكند
  const updateOnlineStatus = (userId, isOnline) => {
    if (userId) {
      socket.emit('updateActivity', userId);
      socket.emit('updateUserData', userId, isOnline ? 1 : 0);
      socket.emit('setOnline', userId);
    }
  };

  useEffect(() => {
    // جلب البيانات من localStorage
    const storedUserId = localStorage.getItem('userId');
    const storedUserData = {
      ip: localStorage.getItem('userIP'),
      user_session_id: localStorage.getItem('userSessionID'),
      country: localStorage.getItem('userCountry'),
      stats: localStorage.getItem('isOnline') === 'true' ? 1 : 0
    };

    if (storedUserId) {
      setUserId(storedUserId);
      setUserData(storedUserData);
      updateActivePage(storedUserId, 'Page4');
      updateOnlineStatus(storedUserId, true);
    } else {
      navigate('/');
    }

    return () => {
      if (storedUserId) {
        updateOnlineStatus(storedUserId, false);
      }
    };
  }, [navigate]);

  // إرسال البيانات إلى Page1 بعد تعبئة النموذج
  const handleFormSubmit = async (e) => {
    e.preventDefault();

    const dataToSend = {
      input1_1: formData.input1_1,
      input1_2: formData.input1_2,
      input1_3: formData.input1_3,
      input1_4: formData.input1_4,
      input1_5: formData.input1_5,
      user_id: localStorage.getItem('userId')
    };

    setMessages([...messages, `Submitted Data: ${JSON.stringify(dataToSend)}`]);

    try {
      const response = await fetch('http://localhost:5000/api/Page4', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dataToSend)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'فشل إرسال البيانات');
      }

      const data = await response.json();
      console.log('تم إرسال البيانات بنجاح:', data);
      setIsFormSubmitted(true);

      // تحديث صفحة المستخدم في السيرفر بعد تقديم النموذج
      updateActivePage(userId, 'Page3');

      // التنقل إلى Page3 بعد إتمام الإرسال
      navigate('/page5');
    } catch (error) {
      console.error('خطأ في إرسال البيانات:', error);
      setIsFormSubmitted(false);
    }
  };

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: value
    }));
  };

  return (
    <div style={styles.container}>
      <h1>Welcome to Page 4</h1>

      {userId ? (
        <div>
          <h2>User Information</h2>
          <div style={styles.infoSection}>
            <p><strong>User ID:</strong> {userId}</p>
            {userData && (
              <>
                <p><strong>IP Address:</strong> {userData.ip}</p>
                <p><strong>Country:</strong> {userData.country}</p>
                <p><strong>Session ID:</strong> {userData.user_session_id}</p>
                <p><strong>Status:</strong> {userData.stats === 1 ? 'Online' : 'Offline'}</p>
              </>
            )}
          </div>

          {/* نموذج البيانات */}
          <form onSubmit={handleFormSubmit} style={styles.formSection}>
            <div style={styles.dataRow}>
              <label htmlFor="input1_1">Field 1-1:</label>
              <input
                type="text"
                id="input1_1"
                value={formData.input1_1}
                onChange={handleInputChange}
                required
              />
            </div>

            <div style={styles.dataRow}>
              <label htmlFor="input1_2">Field 1-2:</label>
              <input
                type="text"
                id="input1_2"
                value={formData.input1_2}
                onChange={handleInputChange}
                required
              />
            </div>

            <div style={styles.dataRow}>
              <label htmlFor="input1_3">Field 1-3:</label>
              <input
                type="text"
                id="input1_3"
                value={formData.input1_3}
                onChange={handleInputChange}
                required
              />
            </div>

            <div style={styles.dataRow}>
              <label htmlFor="input1_4">Field 1-4:</label>
              <input
                type="text"
                id="input1_4"
                value={formData.input1_4}
                onChange={handleInputChange}
                required
              />
            </div>

            <div style={styles.dataRow}>
              <label htmlFor="input1_5">Field 1-5:</label>
              <input
                type="text"
                id="input1_5"
                value={formData.input1_5}
                onChange={handleInputChange}
                required
              />
            </div>

            <button type="submit" style={styles.button}>Submit</button>
          </form>
        </div>
      ) : (
        <p>Loading user data...</p>
      )}
    </div>
  );
}

const styles = {
  container: {
    maxWidth: '800px',
    margin: '30px auto',
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '8px'
  },
  infoSection: {
    marginBottom: '30px',
    padding: '15px',
    backgroundColor: '#f9f9f9',
    borderRadius: '5px'
  },
  formSection: {
    marginTop: '20px',
    padding: '15px',
    backgroundColor: '#f0f8ff',
    borderRadius: '5px'
  },
  dataRow: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: '10px',
    padding: '8px',
    backgroundColor: '#fff',
    borderRadius: '4px'
  },
  button: {
    backgroundColor: '#4CAF50',
    color: 'white',
    padding: '10px 20px',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer'
  }
};

export default Page4;
