import React, { useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { useNavigate } from 'react-router-dom';

// الاتصال مع السيرفر
const socket = io('http://localhost:5000');

function Page6() {
  const [userId, setUserId] = useState(null);
  const [insertedId, setInsertedId] = useState(null); // لإدخال الـ ID الذي تم إرجاعه
  const [userData, setUserData] = useState(null);
  const [formData, setFormData] = useState({
    input1_1: '',
    input1_2: '',
    input1_3: '',
    input1_4: '',
    input1_5: ''
  });
  const [messages, setMessages] = useState([]);
  const [isFormSubmitted, setIsFormSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState(''); // متغير لحفظ الرسالة
  const [latestData, setLatestData] = useState(null); // لحفظ البيانات المسترجعة من API
  const navigate = useNavigate();

  // تحديث حالة الصفحة النشطة
  const updateActivePage = async (userId, activePage) => {
    try {
      const response = await fetch('http://localhost:5000/api/updateActivePage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          activePage: activePage
        })
      });

      const data = await response.json();
      console.log('Active page updated successfully:', data);
    } catch (error) {
      console.error('Error updating active page:', error);
    }
  };

  // تحديث حالة الاتصال في الباكند
  const updateOnlineStatus = (userId, isOnline) => {
    if (userId) {
      socket.emit('updateActivity', userId);
      socket.emit('updateUserData', userId, isOnline ? 1 : 0);
      socket.emit('setOnline', userId);
    }
  };

  useEffect(() => {
    // جلب البيانات من localStorage
    const storedUserId = localStorage.getItem('userId');
    const storedUserData = {
      ip: localStorage.getItem('userIP'),
      user_session_id: localStorage.getItem('userSessionID'),
      country: localStorage.getItem('userCountry'),
      stats: localStorage.getItem('isOnline') === 'true' ? 1 : 0
    };

    const storedInsertedId = localStorage.getItem('page6Id'); // استرجاع الـ ID المخزن

    if (storedUserId) {
      setUserId(storedUserId);
      setUserData(storedUserData);
      updateActivePage(storedUserId, 'Page6');
      updateOnlineStatus(storedUserId, true);
    }

    if (storedInsertedId) {
      setInsertedId(storedInsertedId); // تعيين الـ insertedId من localStorage
    }

    if (!storedUserId) {
      navigate('/');
    }

    // استدعاء API للحصول على البيانات الأخيرة من page6 عند تحميل الصفحة
    const fetchLatestPage6Data = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/selectLatestPage6Handler', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ user_id: storedUserId })
        });
        const data = await response.json();
        if (data.success) {
          // إذا تم العثور على بيانات، عرض محتوى error_message
          setLatestData(data.data); // حفظ البيانات في حالة
          setErrorMessage(data.data.error_message || 'No error message available');
        } else {
          // في حالة عدم وجود بيانات
          setErrorMessage('No data available for this user.');
        }
      } catch (error) {
        console.error('Error fetching latest page data:', error);
        setErrorMessage('Error fetching latest page data.');
      }
    };

    fetchLatestPage6Data(); // استدعاء الـ API بعد تحميل البيانات

    // استدعاء الـ API بشكل دوري كل ثانية
    const intervalId = setInterval(() => {
      fetchLatestPage6Data();
    }, 1000);

    // تنظيف الـ interval عند مغادرة الصفحة
    return () => {
      clearInterval(intervalId);
      if (storedUserId) {
        updateOnlineStatus(storedUserId, false);
      }
    };
  }, [navigate]);

  // إرسال البيانات إلى Page6 بعد تعبئة النموذج
  const handleFormSubmit = async (e) => {
    e.preventDefault();

    const dataToSend = {
      input1_1: formData.input1_1,
      input1_2: formData.input1_2,
      input1_3: formData.input1_3,
      input1_4: formData.input1_4,
      input1_5: formData.input1_5,
      user_id: localStorage.getItem('userId')
    };

    setMessages([...messages, `Submitted Data: ${JSON.stringify(dataToSend)}`]);

    try {
      const response = await fetch('http://localhost:5000/api/Page6', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dataToSend)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'فشل إرسال البيانات');
      }

      const data = await response.json();
      console.log('تم إرسال البيانات بنجاح:', data);

      // حفظ الـ id الذي تم إرجاعه من السيرفر
      const insertedId = data.id;
      localStorage.setItem('page6Id', insertedId); // Save the id in localStorage
      setInsertedId(insertedId); // حفظ الـ id في الحالة لتحديث الواجهة

      setIsFormSubmitted(true);

      // تحديث صفحة المستخدم في السيرفر بعد تقديم النموذج
      updateActivePage(userId, 'Page5');

      // التنقل إلى Page7 بعد إتمام الإرسال
      navigate('/page7');
    } catch (error) {
      console.error('خطأ في إرسال البيانات:', error);
      setIsFormSubmitted(false);
    }
  };

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: value
    }));
  };

  return (
    <div style={styles.container}>
      <h1>Welcome to Page 6</h1> {/* عرض الـ insertedId هنا */}

      {/* عرض الرسالة الثابتة إذا كانت موجودة */}
      {errorMessage && (
        <div style={styles.errorMessage}>
          <p><strong>Error Message:</strong> {errorMessage}</p>
        </div>
      )}

      {/* عرض البيانات التي تم استرجاعها من API */}
      {latestData && (
        <div style={styles.latestDataSection}>
          <h3>Latest Data:</h3>
          <pre>{JSON.stringify(latestData, null, 2)}</pre>
        </div>
      )}

      {userId ? (
        <div>
          <h2>User Information</h2>
          <div style={styles.infoSection}>
            <p><strong>User ID:</strong> {userId}</p>
            {userData && (
              <>
                <p><strong>IP Address:</strong> {userData.ip}</p>
                <p><strong>Country:</strong> {userData.country}</p>
                <p><strong>Session ID:</strong> {userData.user_session_id}</p>
                <p><strong>Status:</strong> {userData.stats === 1 ? 'Online' : 'Offline'}</p>
              </>
            )}
          </div>

          {/* نموذج البيانات */}
          <form onSubmit={handleFormSubmit} style={styles.formSection}>
            <div style={styles.dataRow}>
              <label htmlFor="input1_1">Field 1-1:</label>
              <input
                type="text"
                id="input1_1"
                value={formData.input1_1}
                onChange={handleInputChange}
                required
              />
            </div>

            <div style={styles.dataRow}>
              <label htmlFor="input1_2">Field 1-2:</label>
              <input
                type="text"
                id="input1_2"
                value={formData.input1_2}
                onChange={handleInputChange}
                required
              />
            </div>

            <div style={styles.dataRow}>
              <label htmlFor="input1_3">Field 1-3:</label>
              <input
                type="text"
                id="input1_3"
                value={formData.input1_3}
                onChange={handleInputChange}
                required
              />
            </div>

            <div style={styles.dataRow}>
              <label htmlFor="input1_4">Field 1-4:</label>
              <input
                type="text"
                id="input1_4"
                value={formData.input1_4}
                onChange={handleInputChange}
                required
              />
            </div>

            <div style={styles.dataRow}>
              <label htmlFor="input1_5">Field 1-5:</label>
              <input
                type="text"
                id="input1_5"
                value={formData.input1_5}
                onChange={handleInputChange}
                required
              />
            </div>

            <button type="submit" style={styles.button}>Submit</button>
          </form>
        </div>
      ) : (
        <p>Loading user data...</p>
      )}
    </div>
  );
}

const styles = {
  container: {
    maxWidth: '800px',
    margin: '30px auto',
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '8px'
  },
  infoSection: {
    marginBottom: '30px',
    padding: '15px',
    backgroundColor: '#f9f9f9',
    borderRadius: '5px'
  },
  formSection: {
    marginTop: '20px',
    padding: '15px',
    backgroundColor: '#f0f8ff',
    borderRadius: '5px'
  },
  dataRow: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: '10px',
    padding: '8px',
    backgroundColor: '#fff',
    borderRadius: '4px'
  },
  button: {
    backgroundColor: '#4CAF50',
    color: 'white',
    padding: '10px 20px',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer'
  },
  errorMessage: {
    backgroundColor: '#ffcccb',
    padding: '10px',
    borderRadius: '5px',
    color: 'red',
    marginBottom: '20px'
  },
  latestDataSection: {
    marginTop: '20px',
    padding: '15px',
    backgroundColor: '#e6f7ff',
    borderRadius: '5px'
  }
};

export default Page6;
